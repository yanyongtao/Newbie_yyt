# Github-for-Windows---Offline-Edition
I hate OneClick deployment.

#Current Version: 3.0.6.4
